/** @type {import('next').NextConfig} */
const nextConfig = {
  // no special config needed — works out of the box on Vercel
}

export default nextConfig
// final trigger for vercel sync
