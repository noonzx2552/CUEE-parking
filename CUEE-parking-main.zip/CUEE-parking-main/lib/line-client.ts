const LINE_API = 'https://api.line.me/v2/bot/message'

async function lineRequest(endpoint: string, payload: object) {
  const token = process.env.LINE_CHANNEL_ACCESS_TOKEN
  if (!token) throw new Error('LINE_CHANNEL_ACCESS_TOKEN is not configured.')
  const res = await fetch(`${LINE_API}/${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  })
  if (!res.ok) {
    const body = await res.json().catch(() => ({}))
    throw new Error((body as { message?: string }).message || 'LINE API error')
  }
  return res.json()
}

export function isLineConfigured() {
  return !!process.env.LINE_CHANNEL_ACCESS_TOKEN
}

export function pushMessage(userId: string, messages: object[]) {
  return lineRequest('push', { to: userId, messages })
}

export function replyText(replyToken: string, text: string) {
  return lineRequest('reply', { replyToken, messages: [{ type: 'text', text }] })
}

export function pushParkingTicket(userId: string, slot: string, entranceTime: string) {
  const message = {
    type: 'flex',
    altText: 'SmartPark E-Parking Ticket',
    contents: {
      type: 'bubble',
      header: {
        type: 'box', layout: 'vertical', backgroundColor: '#6366f1',
        contents: [
          { type: 'text', text: 'SMART PARK', color: '#ffffff', weight: 'bold', size: 'lg', fontStyle: 'normal' },
          { type: 'text', text: 'E-Parking Ticket', color: '#e0e7ff', size: 'xs' },
        ],
      },
      body: {
        type: 'box', layout: 'vertical', spacing: 'lg',
        contents: [
          { type: 'box', layout: 'horizontal', spacing: 'md', contents: [
            { type: 'text', text: '✅', size: 'xl', flex: 0 },
            { type: 'text', text: 'ยืนยันเข้าจอดสำเร็จ', weight: 'bold', size: 'lg', color: '#10b981', gravity: 'center' }
          ]},
          { type: 'separator', margin: 'md' },
          { type: 'box', layout: 'vertical', spacing: 'sm', contents: [
            { type: 'box', layout: 'horizontal', contents: [
              { type: 'text', text: 'ช่องจอด', color: '#94a3b8', size: 'md' },
              { type: 'text', text: slot, align: 'end', weight: 'bold', size: 'md', color: '#1e293b' },
            ]},
            { type: 'box', layout: 'horizontal', contents: [
              { type: 'text', text: 'เวลาเข้า', color: '#94a3b8', size: 'md' },
              { type: 'text', text: `${entranceTime} น.`, align: 'end', weight: 'bold', size: 'md', color: '#1e293b' },
            ]},
          ]}
        ],
      },
      footer: {
        type: 'box', layout: 'vertical',
        contents: [
          { type: 'box', layout: 'horizontal', spacing: 'xs', contents: [
            { type: 'text', text: '🔔', size: 'xs', flex: 0 },
            { type: 'text', text: 'ระบบจะแจ้งเตือนเมื่อใกล้ครบเวลา', size: 'xs', color: '#94a3b8', align: 'start' }
          ]}
        ],
      },
    },
  }
  return pushMessage(userId, [message])
}
