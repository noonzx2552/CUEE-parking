import { MongoClient, Db } from 'mongodb'

const uri = process.env.MONGODB_URI
const dbName = process.env.MONGODB_DATABASE || 'smartpark'

if (!uri) {
  console.error("CRITICAL ERROR: MONGODB_URI is not defined in Environment Variables.")
}

let client: MongoClient
let db: Db

declare global {
  // eslint-disable-next-line no-var
  var _mongoClient: MongoClient | undefined
}

async function getDb(): Promise<Db> {
  if (db) return db
  if (!uri) throw new Error('MONGODB_URI is missing in Environment Variables.')

  if (process.env.NODE_ENV === 'development') {
    if (!global._mongoClient) {
      global._mongoClient = new MongoClient(uri)
    }
    client = global._mongoClient
  } else {
    if (!client) client = new MongoClient(uri)
  }

  if (!db) {
    await client.connect()
    db = client.db(dbName)
  }
  return db
}

export { getDb }
